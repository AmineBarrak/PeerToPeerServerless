__version__ = '1.9.0'
debug = False
cuda = None
git_version = 'bc446f6a54ee7c70149b55a4047e2954d480f717'
hip = None
