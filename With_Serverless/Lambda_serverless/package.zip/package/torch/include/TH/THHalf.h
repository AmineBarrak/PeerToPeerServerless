#ifndef TH_HALF_H
#define TH_HALF_H

#include <c10/util/Half.h>

#define THHalf at::Half

#endif
